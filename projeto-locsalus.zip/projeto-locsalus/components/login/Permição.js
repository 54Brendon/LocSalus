import React, { useState } from 'react';
import styled from 'styled-components/native';
import { ScrollView, TouchableOpacity, Alert, Dimensions } from 'react-native';
import * as Location from 'expo-location';
import { useNavigation } from '@react-navigation/native'; // Importe a função useNavigation

const { width, height } = Dimensions.get('window');

const Container = styled.View`
  flex: 1;
  justify-content: center;
  align-items: center;
  background-color: #b8e1f1; /* Fundo azul */
`;

const Content = styled.View`
  align-items: center;
  padding: 0 20px;
`;
const Header = styled.View`
  flex-direction: row;
  align-items: center;
  margin-bottom: 20px;
`;

const Logo = styled.Image`
  width: ${width * 0.2}px;
  height: ${width * 0.2}px;
`;

const ClinicInfo = styled.View`
  margin-left: 10px;
`;

const ClinicName = styled.Text`
  font-family: Inter_500Medium;
`;

const ClinicTime = styled.Text`
  font-family: Inter_700Bold;
  margin-top: 8px;
`;

const Welcome = styled.Text`
  font-size: ${width * 0.07}px; /* Diminui o tamanho do texto */
  font-family: Inter_500Medium;
  margin-bottom: ${height * 0.03}px; /* Diminui o espaço inferior */
`;

const Description = styled.Text`
  font-family: Inter_500Medium;
  text-align: center;
  margin-bottom: ${height * 0.04}px;
`;

const Permission = styled.View`
  flex-direction: row;
  align-items: center;
  margin-bottom: ${height * 0.04}px;
  align-self: flex-start; /* Alinha os itens à esquerda */
`;

const PermissionSquare = styled.View`
  width: ${width * 0.05}px;
  height: ${width * 0.05}px;
  border: 1px solid #000;
  margin-right: 10px;
  align-items: center;
  justify-content: center;
`;

const PermissionCheck = styled.Text`
  font-size: ${width * 0.04}px;
  font-weight: bold;
`;

const PermissionText = styled.Text`
  font-family: Inter_500Medium;
`;

const LocationInfo = styled.Text`
  font-family: Inter_500Medium;
  text-align: center;
  margin-bottom: ${height * 0.04}px;
`;

const Continue = styled.View`
  flex-direction: row;
  align-items: center;
  margin-bottom: ${height * 0.04}px;
`;

const ContinueButton = styled.TouchableOpacity`
  background-color: ${(props) => (props.disabled ? '#ccc' : '#007bff')};
  padding: ${width * 0.04}px ${width * 0.08}px;
  border-radius: 5px;
`;

const ContinueButtonText = styled.Text`
  color: #fff;
  font-family: Inter_500Medium;
`;

const Permição = () => {
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [locationPermissionGranted, setLocationPermissionGranted] = useState(false);
  const [continueDisabled, setContinueDisabled] = useState(true);
  const navigation = useNavigation(); // Inicialize a navegação

  const handleContinue = async () => {
    if (!locationPermissionGranted || !termsAccepted) {
      Alert.alert('Permissões Necessárias', 'Por favor, aceite os termos e conceda permissão de localização para continuar.');
      return;
    }

    navigation.navigate('Cadastro'); // Redirecionar para a rota de cadastro
  };

  const handleLocationPermission = async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status === 'granted') {
      setLocationPermissionGranted(true);
      setContinueDisabled(!termsAccepted);
    }
  };

  const handleTermsAccepted = () => {
    setTermsAccepted(!termsAccepted);
    setContinueDisabled(!locationPermissionGranted);
  };

  return (
    <Container>
      <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center' }}>
        <Content>
          <Header>
            <Logo
              source={{
                uri:
                  'https://cdn.builder.io/api/v1/image/assets/TEMP/abe1b766fb8f1a75ff5dbe4ebc3e4fb370dbc49183eccc345b13fbe6375ff805?apiKey=43087b9600024da7b7591aeaa0192f8a&width=100',
              }}
            />
            <ClinicInfo>
              <ClinicName>Clínica</ClinicName>
              <ClinicTime>30 - 40 min</ClinicTime>
            </ClinicInfo>
          </Header>
          <Welcome>Bem-Vindo!</Welcome>
          <Description>
            Achar e Marcar suas consultas
            {'\n'}
            nunca foi tão fácil!
          </Description>
          <Permission>
            <TouchableOpacity onPress={handleTermsAccepted}>
              <PermissionSquare>{termsAccepted && <PermissionCheck>X</PermissionCheck>}</PermissionSquare>
            </TouchableOpacity>
            <PermissionText>Concordar com os termos de uso</PermissionText>
          </Permission>
          <Permission>
            <TouchableOpacity onPress={handleLocationPermission}>
              <PermissionSquare>{locationPermissionGranted && <PermissionCheck>X</PermissionCheck>}</PermissionSquare>
            </TouchableOpacity>
            <PermissionText>Permitir Localização</PermissionText>
          </Permission>
          <LocationInfo>Para descobrir clínicas perto da sua região</LocationInfo>
          <Continue>
            <ContinueButton disabled={continueDisabled} onPress={handleContinue}>
              <ContinueButtonText>Continuar</ContinueButtonText>
            </ContinueButton>
          </Continue>
        </Content>
      </ScrollView>
    </Container>
  );
};

export default Permição;
