import React from "react";

function MyComponent() {
  const handleEmailClick = () => {
    // Não há a necessidade de exibir nenhuma mensagem ao clicar
    // Podemos deixar esta função vazia
  };

  return (
    <div className="container">
      <div className="title">Validar Email</div>
      <img
        loading="lazy"
        src="https://cdn.builder.io/api/v1/image/assets/TEMP/a0fd1e442575f91b91b20b00239cae54588ee3dbb87e8a8382c1054588f0effc?apiKey=43087b9600024da7b7591aeaa0192f8a&"
        className="image"
        alt="Imagem de código"
        style={{ width: "20%", height: "auto" }} // Reduzido o tamanho da imagem em 80%
      />
      <div className="subtitle">
        Digite o código de 6 dígitos que enviamos para o seu e-mail:
      </div>
      <div className="code-input-container">
        {[...Array(6)].map((_, index) => (
          <input
            key={index}
            type="text"
            maxLength={1}
            className="code-input"
          />
        ))}
      </div>
      <div className="info">Para reenviar o código, espere 0:59</div>
      <span className="not-my-email" onClick={handleEmailClick}>
        Este não é meu e-mail
      </span>
      <div className="continue-container">
        <button className="continue">Continuar</button>
      </div>

      <style jsx global>{`
        body {
          margin: 0;
          padding: 0;
          background-color: #B8E1F1;
          font-family: Arial, sans-serif;
        }

        .container {
          max-width: 100%;
          width: 100%;
          margin: 0 auto;
          padding: 10px;
          text-align: center;
        }

        .title {
          color: #414370;
          font-size: 24px;
          font-weight: bold;
          margin-bottom: 5px;
        }

        .subtitle {
          color: #000;
          font-size: 14px;
          margin-top: 5px;
          margin-bottom: 5px;
        }

        .code-input-container {
          display: flex;
          justify-content: center;
          margin-bottom: 5px;
        }

        .code-input {
          width: 30px;
          height: 30px;
          margin: 0 3px;
          text-align: center;
          font-size: 16px;
          border: 1px solid #ccc;
          border-radius: 3px;
        }

        .info {
          color: #000;
          font-size: 12px;
          margin-top: 5px;
          margin-bottom: 5px;
        }

        .not-my-email {
          color: #414370;
          font-size: 14px;
          font-weight: bold;
          cursor: pointer;
          text-decoration: underline;
          margin-bottom: 5px;
        }

        .continue-container {
          margin-top: 10px;
        }

        .continue {
          background-color: #414370;
          color: #fff;
          font-size: 14px;
          font-weight: bold;
          border: none;
          border-radius: 3px;
          padding: 5px 10px;
          cursor: pointer;
        }
      `}</style>
    </div>
  );
}

export default MyComponent;
